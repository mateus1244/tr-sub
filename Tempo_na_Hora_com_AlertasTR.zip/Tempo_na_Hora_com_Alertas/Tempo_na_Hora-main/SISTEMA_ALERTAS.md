# Sistema de Alertas Personalizados - Previsão do Tempo

## Visão Geral

Este sistema permite criar alertas personalizados para monitorar condições climáticas específicas, como temperatura acima de 30°C ou qualidade do ar ruim. Os alertas são verificados automaticamente sempre que uma nova previsão é consultada.

## Funcionalidades Implementadas

### 1. Modelo de Dados (Alerta)

O modelo `Alerta` contém os seguintes campos:

- **id**: Identificador único do alerta
- **nome**: Nome descritivo do alerta (ex: "Alerta de Calor Extremo")
- **tipo**: Tipo de monitoramento (`TEMPERATURA`, `UMIDADE`, `QUALIDADE_AR`)
- **condicao**: Condição de disparo (`MAIOR_QUE`, `MENOR_QUE`, `IGUAL_A`)
- **valorReferencia**: Valor de referência para comparação
- **cidade**: Cidade a ser monitorada
- **ativo**: Indica se o alerta está ativo ou desativado
- **dataCriacao**: Data de criação do alerta
- **dataUltimoDisparo**: Data do último disparo do alerta
- **mensagemPersonalizada**: Mensagem customizada (opcional)

### 2. Endpoints da API

#### Gerenciamento de Alertas (`/alertas`)

**POST /alertas** - Criar novo alerta
```json
{
  "nome": "Alerta de Calor",
  "tipo": "TEMPERATURA",
  "condicao": "MAIOR_QUE",
  "valorReferencia": 30.0,
  "cidade": "São Paulo",
  "mensagemPersonalizada": "⚠️ Atenção! Temperatura acima de 30°C em São Paulo!"
}
```

**GET /alertas** - Listar todos os alertas

**GET /alertas/ativos** - Listar apenas alertas ativos

**GET /alertas/{id}** - Buscar alerta por ID

**PATCH /alertas/{id}/status?ativo=true** - Ativar/desativar alerta

**DELETE /alertas/{id}** - Excluir alerta

#### Consulta de Previsão com Alertas

**GET /previsoes/consultar-com-alertas?cidade=São Paulo**

Retorna a previsão do tempo junto com os alertas disparados:

```json
{
  "previsao": {
    "id": 1,
    "cidade": "São Paulo",
    "descricao": "céu limpo",
    "temperatura": 32.5,
    "umidade": 45.0,
    "dataHoraConsulta": "2025-12-08T12:00:00"
  },
  "alertasDisparados": [
    "⚠️ Atenção! Temperatura acima de 30°C em São Paulo!"
  ],
  "temAlertas": true
}
```

## Exemplos de Uso

### Exemplo 1: Alerta de Temperatura Alta

```json
{
  "nome": "Alerta de Calor Extremo",
  "tipo": "TEMPERATURA",
  "condicao": "MAIOR_QUE",
  "valorReferencia": 30.0,
  "cidade": "Rio de Janeiro",
  "mensagemPersonalizada": "🌡️ ATENÇÃO: Temperatura acima de 30°C no Rio de Janeiro!"
}
```

### Exemplo 2: Alerta de Umidade Baixa

```json
{
  "nome": "Alerta de Ar Seco",
  "tipo": "UMIDADE",
  "condicao": "MENOR_QUE",
  "valorReferencia": 30.0,
  "cidade": "Brasília",
  "mensagemPersonalizada": "💧 ATENÇÃO: Umidade do ar muito baixa em Brasília!"
}
```

### Exemplo 3: Alerta de Temperatura Baixa

```json
{
  "nome": "Alerta de Frio",
  "tipo": "TEMPERATURA",
  "condicao": "MENOR_QUE",
  "valorReferencia": 10.0,
  "cidade": "Curitiba",
  "mensagemPersonalizada": "❄️ ATENÇÃO: Temperatura abaixo de 10°C em Curitiba!"
}
```

## Como Funciona

1. **Criação de Alertas**: O usuário cria alertas através do endpoint POST `/alertas`

2. **Consulta de Previsão**: Quando uma previsão é consultada (via `/previsoes/consultar` ou `/previsoes/consultar-com-alertas`), o sistema:
   - Busca os dados da API OpenWeatherMap
   - Salva a previsão no banco de dados
   - Verifica automaticamente todos os alertas ativos para aquela cidade
   - Compara os valores (temperatura, umidade) com as condições configuradas
   - Dispara os alertas que atendem às condições

3. **Notificação**: Os alertas disparados são:
   - Exibidos no console do servidor
   - Retornados na resposta da API (endpoint `/consultar-com-alertas`)
   - Registrados com a data do último disparo

## Tipos de Alertas Suportados

### Tipo: TEMPERATURA
- Monitora a temperatura em graus Celsius
- Condições: `MAIOR_QUE`, `MENOR_QUE`, `IGUAL_A`

### Tipo: UMIDADE
- Monitora a umidade relativa do ar (%)
- Condições: `MAIOR_QUE`, `MENOR_QUE`, `IGUAL_A`

### Tipo: QUALIDADE_AR (Futuro)
- Preparado para integração futura com APIs de qualidade do ar
- Condições: `MAIOR_QUE`, `MENOR_QUE`, `IGUAL_A`

## Integração com Sistema Existente

O sistema de alertas foi integrado de forma não invasiva:

- **PrevisaoService**: Modificado para verificar alertas após salvar cada previsão
- **PrevisaoController**: Adicionado novo endpoint `/consultar-com-alertas` que retorna alertas junto com a previsão
- **Novos componentes**: 
  - `Alerta` (model)
  - `AlertaRepository` (repository)
  - `AlertaService` (service)
  - `AlertaController` (controller)
  - `AlertaDTO` e `PrevisaoComAlertasDTO` (DTOs)

## Observações Importantes

1. **Múltiplos Alertas**: É possível criar vários alertas para a mesma cidade com diferentes condições
2. **Ativação/Desativação**: Alertas podem ser desativados temporariamente sem serem excluídos
3. **Histórico**: O campo `dataUltimoDisparo` registra quando o alerta foi disparado pela última vez
4. **Mensagens Personalizadas**: Se não fornecida, uma mensagem padrão é gerada automaticamente
5. **Verificação Automática**: Os alertas são verificados automaticamente a cada consulta de previsão

## Testes

Para testar o sistema:

1. Inicie a aplicação Spring Boot
2. Crie um alerta usando o endpoint POST `/alertas`
3. Consulte a previsão para a cidade configurada usando `/previsoes/consultar-com-alertas`
4. Verifique os alertas disparados na resposta da API e no console do servidor

## Melhorias Futuras

- Integração com serviços de notificação (email, SMS, push)
- Suporte para qualidade do ar usando APIs específicas
- Dashboard web para gerenciamento visual de alertas
- Histórico completo de disparos de alertas
- Alertas baseados em múltiplas condições combinadas
- Integração com sistemas de mensageria (RabbitMQ, Kafka)
