# Exemplos de Teste do Sistema de Alertas

## Pré-requisitos

1. Aplicação Spring Boot rodando
2. Ferramenta para fazer requisições HTTP (Postman, Insomnia, curl, etc.)
3. Swagger UI disponível em: `http://localhost:8080/swagger-ui.html`

## Cenário 1: Criar e Testar Alerta de Temperatura Alta

### Passo 1: Criar o Alerta

**Requisição:**
```http
POST http://localhost:8080/alertas
Content-Type: application/json

{
  "nome": "Alerta de Calor em São Paulo",
  "tipo": "TEMPERATURA",
  "condicao": "MAIOR_QUE",
  "valorReferencia": 30.0,
  "cidade": "São Paulo",
  "mensagemPersonalizada": "⚠️ ATENÇÃO: Temperatura acima de 30°C em São Paulo!"
}
```

**Resposta Esperada:**
```json
{
  "id": 1,
  "nome": "Alerta de Calor em São Paulo",
  "tipo": "TEMPERATURA",
  "condicao": "MAIOR_QUE",
  "valorReferencia": 30.0,
  "cidade": "São Paulo",
  "ativo": true,
  "dataCriacao": "2025-12-08T12:00:00",
  "dataUltimoDisparo": null,
  "mensagemPersonalizada": "⚠️ ATENÇÃO: Temperatura acima de 30°C em São Paulo!"
}
```

### Passo 2: Consultar Previsão com Alertas

**Requisição:**
```http
GET http://localhost:8080/previsoes/consultar-com-alertas?cidade=São Paulo
```

**Resposta (se temperatura > 30°C):**
```json
{
  "previsao": {
    "id": 5,
    "cidade": "São Paulo",
    "descricao": "céu limpo",
    "temperatura": 32.5,
    "umidade": 45.0,
    "dataHoraConsulta": "2025-12-08T12:30:00"
  },
  "alertasDisparados": [
    "⚠️ ATENÇÃO: Temperatura acima de 30°C em São Paulo!"
  ],
  "temAlertas": true
}
```

## Cenário 2: Criar Múltiplos Alertas para Mesma Cidade

### Alerta 1: Temperatura Alta
```http
POST http://localhost:8080/alertas
Content-Type: application/json

{
  "nome": "Calor Extremo",
  "tipo": "TEMPERATURA",
  "condicao": "MAIOR_QUE",
  "valorReferencia": 35.0,
  "cidade": "Rio de Janeiro",
  "mensagemPersonalizada": "🔥 ALERTA VERMELHO: Calor extremo no Rio de Janeiro!"
}
```

### Alerta 2: Umidade Baixa
```http
POST http://localhost:8080/alertas
Content-Type: application/json

{
  "nome": "Ar Seco",
  "tipo": "UMIDADE",
  "condicao": "MENOR_QUE",
  "valorReferencia": 30.0,
  "cidade": "Rio de Janeiro",
  "mensagemPersonalizada": "💧 ATENÇÃO: Umidade do ar muito baixa no Rio!"
}
```

### Consultar com Múltiplos Alertas
```http
GET http://localhost:8080/previsoes/consultar-com-alertas?cidade=Rio de Janeiro
```

**Resposta (ambos alertas disparados):**
```json
{
  "previsao": {
    "id": 6,
    "cidade": "Rio de Janeiro",
    "descricao": "céu limpo",
    "temperatura": 36.0,
    "umidade": 25.0,
    "dataHoraConsulta": "2025-12-08T13:00:00"
  },
  "alertasDisparados": [
    "🔥 ALERTA VERMELHO: Calor extremo no Rio de Janeiro!",
    "💧 ATENÇÃO: Umidade do ar muito baixa no Rio!"
  ],
  "temAlertas": true
}
```

## Cenário 3: Gerenciar Alertas

### Listar Todos os Alertas
```http
GET http://localhost:8080/alertas
```

### Listar Apenas Alertas Ativos
```http
GET http://localhost:8080/alertas/ativos
```

### Buscar Alerta Específico
```http
GET http://localhost:8080/alertas/1
```

### Desativar um Alerta
```http
PATCH http://localhost:8080/alertas/1/status?ativo=false
```

### Reativar um Alerta
```http
PATCH http://localhost:8080/alertas/1/status?ativo=true
```

### Excluir um Alerta
```http
DELETE http://localhost:8080/alertas/1
```

## Cenário 4: Alerta de Frio

```http
POST http://localhost:8080/alertas
Content-Type: application/json

{
  "nome": "Alerta de Frio Intenso",
  "tipo": "TEMPERATURA",
  "condicao": "MENOR_QUE",
  "valorReferencia": 10.0,
  "cidade": "Curitiba",
  "mensagemPersonalizada": "❄️ ALERTA: Temperatura abaixo de 10°C em Curitiba!"
}
```

## Cenário 5: Alerta sem Mensagem Personalizada

```http
POST http://localhost:8080/alertas
Content-Type: application/json

{
  "nome": "Monitoramento de Temperatura",
  "tipo": "TEMPERATURA",
  "condicao": "MAIOR_QUE",
  "valorReferencia": 28.0,
  "cidade": "Salvador"
}
```

**Quando disparado, a mensagem padrão será:**
```
ALERTA: Monitoramento de Temperatura - TEMPERATURA está maior que 28.0 (valor atual: 29.5) em Salvador
```

## Testes via cURL

### Criar Alerta
```bash
curl -X POST http://localhost:8080/alertas \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Alerta de Calor",
    "tipo": "TEMPERATURA",
    "condicao": "MAIOR_QUE",
    "valorReferencia": 30.0,
    "cidade": "São Paulo",
    "mensagemPersonalizada": "⚠️ Temperatura alta!"
  }'
```

### Consultar Previsão com Alertas
```bash
curl -X GET "http://localhost:8080/previsoes/consultar-com-alertas?cidade=São%20Paulo"
```

### Listar Alertas Ativos
```bash
curl -X GET http://localhost:8080/alertas/ativos
```

### Desativar Alerta
```bash
curl -X PATCH "http://localhost:8080/alertas/1/status?ativo=false"
```

## Verificação no Console

Quando um alerta é disparado, você verá no console do servidor:

```
========== ALERTAS DISPARADOS ==========
⚠️  ⚠️ ATENÇÃO: Temperatura acima de 30°C em São Paulo!
========================================
```

## Dicas de Teste

1. **Teste com cidades reais**: Use cidades que você conhece a temperatura atual
2. **Ajuste os valores**: Configure valores de referência próximos à temperatura real para garantir que os alertas disparem
3. **Teste desativação**: Desative um alerta e verifique que ele não dispara mais
4. **Múltiplos alertas**: Crie vários alertas para a mesma cidade com condições diferentes
5. **Mensagens personalizadas**: Teste com e sem mensagens personalizadas

## Validações

O sistema valida:
- Nome do alerta: 3-100 caracteres
- Cidade: 2-100 caracteres
- Tipo: deve ser válido (TEMPERATURA, UMIDADE, QUALIDADE_AR)
- Condição: deve ser válida (MAIOR_QUE, MENOR_QUE, IGUAL_A)
- Valor de referência: não pode ser nulo

Exemplo de erro de validação:
```json
{
  "timestamp": "2025-12-08T12:00:00",
  "status": 400,
  "error": "Bad Request",
  "message": "Nome do alerta deve ter entre 3 e 100 caracteres"
}
```
