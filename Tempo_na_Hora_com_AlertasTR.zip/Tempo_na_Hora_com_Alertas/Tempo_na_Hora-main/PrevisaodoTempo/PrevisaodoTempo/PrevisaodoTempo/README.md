# Previsão do Tempo - API REST

Uma aplicação Spring Boot robusta para gerenciamento de previsões do tempo com integração à API OpenWeatherMap, autenticação com Spring Security e documentação automática com Swagger.

## 📋 Requisitos

- **Java 17+**
- **Maven 3.8+**
- **PostgreSQL 12+**
- **Chave API OpenWeatherMap** (obtenha em https://openweathermap.org/api)

## 🚀 Configuração e Setup

### 1. Clonar o Repositório

```bash
git clone <seu-repositorio>
cd PrevisaodoTempo
```

### 2. Configurar Banco de Dados PostgreSQL

Crie um banco de dados PostgreSQL:

```sql
CREATE DATABASE previsao_do_tempo;
```

### 3. Configurar Variáveis de Ambiente

Edite o arquivo `src/main/resources/application.properties`:

```properties
# Banco de Dados
spring.datasource.url=jdbc:postgresql://localhost:5432/previsao_do_tempo
spring.datasource.username=postgres
spring.datasource.password=sua_senha_aqui

# Chave da API OpenWeatherMap
weather.api.key=sua_chave_api_aqui

# Porta do servidor
server.port=3000
```

### 4. Compilar e Executar

```bash
# Compilar o projeto
mvn clean install

# Executar a aplicação
mvn spring-boot:run
```

A aplicação estará disponível em: `http://localhost:3000`

## 📚 Documentação da API

### Swagger UI

Acesse a documentação interativa em:

```
http://localhost:3000/swagger-ui.html
```

### Endpoints Principais

#### 1. **Listar Todas as Previsões**

```http
GET /previsoes/Lista
```

**Resposta (200 OK):**
```json
[
  {
    "id": 1,
    "cidade": "São Paulo",
    "descricao": "Céu limpo",
    "temperatura": 25.5,
    "umidade": 70.0,
    "dataHoraConsulta": "2024-11-25T10:30:00"
  }
]
```

#### 2. **Buscar Previsão por ID**

```http
GET /previsoes/1/{id}
```

**Parâmetros:**
- `id` (Long): ID da previsão

**Resposta (200 OK):**
```json
{
  "id": 1,
  "cidade": "São Paulo",
  "descricao": "Céu limpo",
  "temperatura": 25.5,
  "umidade": 70.0,
  "dataHoraConsulta": "2024-11-25T10:30:00"
}
```

#### 3. **Criar Nova Previsão**

```http
POST /previsoes
Content-Type: application/json

{
  "cidade": "Rio de Janeiro",
  "descricao": "Parcialmente nublado",
  "temperatura": 28.0,
  "umidade": 65.0,
  "dataHoraConsulta": "2024-11-25T10:30:00"
}
```

**Resposta (200 OK):**
```json
{
  "id": 2,
  "cidade": "Rio de Janeiro",
  "descricao": "Parcialmente nublado",
  "temperatura": 28.0,
  "umidade": 65.0,
  "dataHoraConsulta": "2024-11-25T10:30:00"
}
```

#### 4. **Atualizar Previsão**

```http
PUT /previsoes/2/{id}
Content-Type: application/json

{
  "cidade": "Rio de Janeiro",
  "descricao": "Nublado com chuva",
  "temperatura": 22.0,
  "umidade": 85.0,
  "dataHoraConsulta": "2024-11-25T10:30:00"
}
```

**Resposta (200 OK):**
```json
{
  "id": 2,
  "cidade": "Rio de Janeiro",
  "descricao": "Nublado com chuva",
  "temperatura": 22.0,
  "umidade": 85.0,
  "dataHoraConsulta": "2024-11-25T10:30:00"
}
```

#### 5. **Excluir Previsão**

```http
DELETE /previsoes/3/{id}
```

**Resposta (204 No Content)**

#### 6. **Consultar Previsão por Cidade (API Externa)**

```http
GET /previsoes/consultar?cidade=São Paulo
```

**Parâmetros:**
- `cidade` (String): Nome da cidade

**Resposta (200 OK):**
```json
{
  "id": 3,
  "cidade": "São Paulo",
  "descricao": "Céu limpo",
  "temperatura": 25.5,
  "umidade": 70.0,
  "dataHoraConsulta": "2024-11-25T10:30:00"
}
```

## ✅ Validações

A API valida automaticamente os dados de entrada:

| Campo | Validação | Mensagem de Erro |
| :--- | :--- | :--- |
| `cidade` | Não pode estar vazio, 2-100 caracteres | "Cidade não pode estar vazia" |
| `descricao` | Não pode estar vazio, 5-255 caracteres | "Descrição não pode estar vazia" |
| `temperatura` | Entre -50°C e 60°C | "Temperatura não pode ser menor que -50°C" |
| `umidade` | Entre 0 e 100 | "Umidade deve estar entre 0 e 100" |
| `dataHoraConsulta` | Não pode ser nula | "Data/Hora da consulta não pode ser nula" |

## 🧪 Testes

### Executar Testes Unitários

```bash
mvn test
```

### Executar Testes de Integração

```bash
mvn test -Dgroups=integration
```

### Testes Incluídos

1. **PrevisaoServiceTest** - Testes unitários do serviço
2. **PrevisaoControllerIntegrationTest** - Testes de integração do controller

## 🔐 Segurança

A aplicação utiliza **Spring Security** para proteção. Endpoints sensíveis requerem autenticação.

### Configuração de Segurança

- Autenticação: Spring Security
- Validação: Bean Validation (Jakarta Validation)
- CORS: Configurado para localhost

## 🛠️ Estrutura do Projeto

```
PrevisaodoTempo/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── br/unipar/programacaoweb/previsaodotempo/
│   │   │       ├── config/           # Configurações
│   │   │       ├── controller/       # Controllers REST
│   │   │       ├── dto/              # Data Transfer Objects
│   │   │       ├── exception/        # Exceções customizadas
│   │   │       ├── model/            # Entidades JPA
│   │   │       ├── repository/       # Repositórios
│   │   │       └── service/          # Serviços
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── br/unipar/programacaoweb/previsaodotempo/
│               ├── controller/       # Testes de controller
│               └── service/          # Testes de serviço
├── pom.xml
└── README.md
```

## 📦 Dependências Principais

- **Spring Boot 3.5.7**
- **Spring Data JPA**
- **Spring Security**
- **PostgreSQL Driver**
- **Lombok**
- **Springdoc OpenAPI (Swagger)**
- **Jakarta Validation**

## 🐛 Tratamento de Erros

A API retorna respostas de erro padronizadas:

```json
{
  "timestamp": "2024-11-25T10:30:00",
  "status": 400,
  "message": "Erro de validação",
  "details": {
    "cidade": "Cidade não pode estar vazia"
  },
  "path": "/previsoes"
}
```

## 📝 Exemplos de Uso com cURL

### Listar todas as previsões

```bash
curl -X GET http://localhost:3000/previsoes/Lista
```

### Criar nova previsão

```bash
curl -X POST http://localhost:3000/previsoes \
  -H "Content-Type: application/json" \
  -d '{
    "cidade": "Belo Horizonte",
    "descricao": "Céu limpo",
    "temperatura": 26.0,
    "umidade": 60.0,
    "dataHoraConsulta": "2024-11-25T10:30:00"
  }'
```

### Buscar previsão por ID

```bash
curl -X GET http://localhost:3000/previsoes/1/1
```

### Atualizar previsão

```bash
curl -X PUT http://localhost:3000/previsoes/2/1 \
  -H "Content-Type: application/json" \
  -d '{
    "cidade": "Belo Horizonte",
    "descricao": "Nublado",
    "temperatura": 24.0,
    "umidade": 75.0,
    "dataHoraConsulta": "2024-11-25T10:30:00"
  }'
```

### Excluir previsão

```bash
curl -X DELETE http://localhost:3000/previsoes/3/1
```

## 🤝 Contribuindo

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## 👥 Autores

- Desenvolvido como projeto acadêmico para a disciplina de Programação Web

## 📞 Suporte

Para suporte, abra uma issue no repositório ou entre em contato através do email de suporte.

---

**Última atualização:** 25 de novembro de 2024
