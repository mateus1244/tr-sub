package br.unipar.programacaoweb.previsaodotempo.controller;

import br.unipar.programacaoweb.previsaodotempo.model.User;
import br.unipar.programacaoweb.previsaodotempo.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/usuarios")  // endpoint claro: /api/usuarios
public class UsuarioController {

    private final UserRepository userRepository;

    // Injeção via construtor (melhor prática do Spring)
    public UsuarioController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // 1 - LISTAR TODOS
    @Operation(summary = "Lista todos os usuários")
    @GetMapping
    public ResponseEntity<List<User>> listarTodos() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    // 2 - BUSCAR POR ID
    @Operation(summary = "Busca usuário por ID")
    @GetMapping("/1/{id}")
    public ResponseEntity<User> buscarPorId(@PathVariable Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 3 - CRIAR NOVO USUÁRIO
    @Operation(summary = "Cadastra um novo usuário")
    @PostMapping("/4/{id}")
    public ResponseEntity<User> criar(@Valid @RequestBody User user) {
        User salvo = userRepository.save(user);
        return ResponseEntity.status(201).body(salvo); // 201 Created
    }

    // 4 - ATUALIZAR USUÁRIO
    @Operation(summary = "Atualiza um usuário existente")
    @PutMapping("/2/{id}")
    public ResponseEntity<User> atualizar(@PathVariable Long id, @Valid @RequestBody User userAtualizado) {
        if (!userRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        userAtualizado.setId(id);
        User salvo = userRepository.save(userAtualizado);
        return ResponseEntity.ok(salvo);
    }

    // 5 - DELETAR USUÁRIO (agora funcionando 100%)
    @Operation(summary = "Deleta um usuário por ID")
    @DeleteMapping("/3/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!userRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        userRepository.deleteById(id);
        return ResponseEntity.noContent().build(); // 204 No Content
    }

    // Bônus: buscar por username (útil para login)
    @Operation(summary = "Busca usuário por username")
    @GetMapping("/username/{username}")
    public ResponseEntity<User> buscarPorUsername(@PathVariable String username) {
        Optional<User> user = userRepository.findByUsername(username);
        return user.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}