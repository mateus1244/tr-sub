package br.unipar.programacaoweb.previsaodotempo.model;

public class Usuario {
}
