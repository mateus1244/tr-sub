package br.unipar.programacaoweb.previsaodotempo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AlertaDTO {

    @NotBlank(message = "Nome do alerta não pode estar vazio")
    @Size(min = 3, max = 100, message = "Nome do alerta deve ter entre 3 e 100 caracteres")
    private String nome;

    @NotBlank(message = "Tipo de alerta não pode estar vazio")
    private String tipo; // "TEMPERATURA", "UMIDADE", "QUALIDADE_AR"

    @NotBlank(message = "Condição não pode estar vazia")
    private String condicao; // "MAIOR_QUE", "MENOR_QUE", "IGUAL_A"

    @NotNull(message = "Valor de referência não pode ser nulo")
    private Double valorReferencia;

    @NotBlank(message = "Cidade não pode estar vazia")
    @Size(min = 2, max = 100, message = "Cidade deve ter entre 2 e 100 caracteres")
    private String cidade;

    private String mensagemPersonalizada;
}
