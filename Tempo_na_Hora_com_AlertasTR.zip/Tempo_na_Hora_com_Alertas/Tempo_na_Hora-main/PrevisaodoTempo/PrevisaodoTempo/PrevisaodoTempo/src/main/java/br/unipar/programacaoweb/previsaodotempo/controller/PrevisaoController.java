package br.unipar.programacaoweb.previsaodotempo.controller;

import br.unipar.programacaoweb.previsaodotempo.dto.PrevisaoComAlertasDTO;
import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import br.unipar.programacaoweb.previsaodotempo.service.AlertaService;
import br.unipar.programacaoweb.previsaodotempo.service.PrevisaoService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/previsoes")
public class PrevisaoController {

    private final PrevisaoService service;
    private final AlertaService alertaService;

    public PrevisaoController(PrevisaoService service, AlertaService alertaService) {
        this.service = service;
        this.alertaService = alertaService;
    }

    @Operation(summary = "Lista todas as previsões")
    @GetMapping ("/Lista")
    public ResponseEntity<List<PrevisaoClimatica>> listar() {
        return ResponseEntity.ok(service.listarTodas());
    }

   /* @Operation(summary = "Busca previsão por ID")
    @GetMapping("/1/{id}")
    public ResponseEntity<PrevisaoClimatica> buscar(@PathVariable Long id) {
        var previsao = service.buscarPorId(id);
        if (previsao == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(previsao);
    }*/

   /*@Operation(summary = "Salva uma nova previsão")
    @PostMapping
    public ResponseEntity<PrevisaoClimatica> salvar(@Valid @RequestBody PrevisaoClimatica previsao) {
        return ResponseEntity.ok(service.salvar(previsao));
    } */


   /* @Operation(summary = "Atualiza uma previsão pelo ID")
    @PutMapping("/2/{id}")
    public ResponseEntity<PrevisaoClimatica> atualizar(@PathVariable Long id, @Valid @RequestBody PrevisaoClimatica previsao) {
        var existente = service.buscarPorId(id);
        if (existente == null) return ResponseEntity.notFound().build();

        existente.setCidade(previsao.getCidade());
        existente.setDescricao(previsao.getDescricao());
        existente.setTemperatura(previsao.getTemperatura());
        existente.setUmidade(previsao.getUmidade());
        existente.setDataHoraConsulta(previsao.getDataHoraConsulta());

        return ResponseEntity.ok(service.salvar(existente));
    }
*/
   /* @Operation(summary = "Exclui uma previsão pelo ID")
    @DeleteMapping("/3/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        var previsao = service.buscarPorId(id);
        if (previsao == null) return ResponseEntity.notFound().build();
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }*/




    @Operation(summary = "Consulta previsão para uma cidade via API externa e salva")
    @GetMapping("/consultar")
    public ResponseEntity<PrevisaoClimatica> consultarCidade(@RequestParam String cidade) {
        var previsao = service.obterPrevisaoPorCidade(cidade);
        if (previsao == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(previsao);
    }

    @Operation(summary = "Consulta previsão com verificação de alertas")
    @GetMapping("/consultar-com-alertas")
    public ResponseEntity<PrevisaoComAlertasDTO> consultarCidadeComAlertas(@RequestParam String cidade) {
        var previsao = service.obterPrevisaoPorCidade(cidade);
        if (previsao == null) return ResponseEntity.notFound().build();
        
        var alertasDisparados = alertaService.verificarAlertas(previsao);
        var response = new PrevisaoComAlertasDTO(
            previsao,
            alertasDisparados,
            !alertasDisparados.isEmpty()
        );
        
        return ResponseEntity.ok(response);
    }
/*
    @Operation(summary = "Consulta previsão para uma cidade via API externa usando o ID da cidade e salva")
    @GetMapping("/consultarPorId")
    public ResponseEntity<PrevisaoClimatica> consultarCidadePorId(@RequestParam Long id) {
        var previsao = service.obterPrevisaoPorId(id);
        if (previsao == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(previsao);
    }*/
}
