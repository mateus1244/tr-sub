package br.unipar.programacaoweb.previsaodotempo.controller;

import br.unipar.programacaoweb.previsaodotempo.dto.AlertaDTO;
import br.unipar.programacaoweb.previsaodotempo.model.Alerta;
import br.unipar.programacaoweb.previsaodotempo.service.AlertaService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alertas")
public class AlertaController {

    private final AlertaService alertaService;

    public AlertaController(AlertaService alertaService) {
        this.alertaService = alertaService;
    }

    @Operation(summary = "Cria um novo alerta personalizado")
    @PostMapping
    public ResponseEntity<Alerta> criarAlerta(@Valid @RequestBody AlertaDTO alertaDTO) {
        Alerta alerta = alertaService.criarAlerta(alertaDTO);
        return ResponseEntity.ok(alerta);
    }

    @Operation(summary = "Lista todos os alertas cadastrados")
    @GetMapping
    public ResponseEntity<List<Alerta>> listarTodosAlertas() {
        return ResponseEntity.ok(alertaService.listarTodosAlertas());
    }

    @Operation(summary = "Lista apenas alertas ativos")
    @GetMapping("/ativos")
    public ResponseEntity<List<Alerta>> listarAlertasAtivos() {
        return ResponseEntity.ok(alertaService.listarAlertasAtivos());
    }

    @Operation(summary = "Busca um alerta por ID")
    @GetMapping("/{id}")
    public ResponseEntity<Alerta> buscarAlertaPorId(@PathVariable Long id) {
        Alerta alerta = alertaService.buscarAlertaPorId(id);
        if (alerta == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(alerta);
    }

    @Operation(summary = "Ativa ou desativa um alerta")
    @PatchMapping("/{id}/status")
    public ResponseEntity<Alerta> alterarStatusAlerta(@PathVariable Long id, @RequestParam Boolean ativo) {
        Alerta alerta = alertaService.alterarStatusAlerta(id, ativo);
        if (alerta == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(alerta);
    }

    @Operation(summary = "Exclui um alerta")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirAlerta(@PathVariable Long id) {
        Alerta alerta = alertaService.buscarAlertaPorId(id);
        if (alerta == null) {
            return ResponseEntity.notFound().build();
        }
        alertaService.excluirAlerta(id);
        return ResponseEntity.noContent().build();
    }
}
