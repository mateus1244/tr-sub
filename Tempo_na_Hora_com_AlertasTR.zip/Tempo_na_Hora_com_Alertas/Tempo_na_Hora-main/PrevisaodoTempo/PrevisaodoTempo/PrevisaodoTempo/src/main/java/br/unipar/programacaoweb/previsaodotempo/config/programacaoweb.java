
package br.unipar.programacaoweb.previsaodotempo.config;

import br.unipar.programacaoweb.previsaodotempo.PrevisaoDoTempoApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class programacaoweb {

    public static void main(String[] args) {
        SpringApplication.run(PrevisaoDoTempoApplication.class, args);
        System.out.println("Acesse: http://localhost:8085");
        System.out.println("Swagger UI: http://localhost:8085/swagger-ui.html");
        System.out.println("Login: http://localhost:8085/auth/login");
    }
}

