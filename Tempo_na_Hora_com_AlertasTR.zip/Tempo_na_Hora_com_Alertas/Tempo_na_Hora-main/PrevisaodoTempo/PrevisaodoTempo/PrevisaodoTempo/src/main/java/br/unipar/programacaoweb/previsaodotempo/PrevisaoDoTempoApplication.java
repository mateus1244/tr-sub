package br.unipar.programacaoweb.previsaodotempo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrevisaoDoTempoApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrevisaoDoTempoApplication.class, args);
    }

}
