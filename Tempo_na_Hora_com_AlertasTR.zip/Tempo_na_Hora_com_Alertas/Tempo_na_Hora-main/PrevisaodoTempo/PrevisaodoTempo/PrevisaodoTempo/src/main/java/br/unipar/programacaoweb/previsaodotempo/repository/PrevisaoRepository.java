package br.unipar.programacaoweb.previsaodotempo.repository;

import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**Repositório  entidade PrevisaoClimatica
 * Fornece operações CRUD e consultas customizadas*/
@Repository
public interface PrevisaoRepository extends JpaRepository<PrevisaoClimatica, Long> {

    /**
     * Busca previsões por nome da cidade
     * @param cidade Nome da cidade
     * @return Lista de previsões da cidade
     */
    List<PrevisaoClimatica> findByCidade(String cidade);

    /**
     * Busca a previsão mais recente de uma cidade
     * @param cidade Nome da cidade
     * @return Optional contendo a previsão mais recente
     */
    Optional<PrevisaoClimatica> findFirstByCidadeOrderByDataHoraConsultaDesc(String cidade);
}