package br.unipar.programacaoweb.previsaodotempo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PrevisaoClimatica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Cidade não pode estar vazia")
    @Size(min = 2, max = 100, message = "Cidade deve ter entre 2 e 100 caracteres")
    private String cidade;

    @NotBlank(message = "Descrição não pode estar vazia")
    @Size(min = 5, max = 255, message = "Descrição deve ter entre 5 e 255 caracteres")
    private String descricao;

    @NotNull(message = "Temperatura não pode ser nula")
    @DecimalMin(value = "-50.0", message = "Temperatura não pode ser menor que -50°C")
    @DecimalMax(value = "60.0", message = "Temperatura não pode ser maior que 60°C")
    private double temperatura;

    @NotNull(message = "Umidade não pode ser nula")
    @DecimalMin(value = "0.0", message = "Umidade deve estar entre 0 e 100")
    @DecimalMax(value = "100.0", message = "Umidade deve estar entre 0 e 100")
    private double umidade;

    @NotNull(message = "Data/Hora da consulta não pode ser nula")
    private LocalDateTime dataHoraConsulta;
}
