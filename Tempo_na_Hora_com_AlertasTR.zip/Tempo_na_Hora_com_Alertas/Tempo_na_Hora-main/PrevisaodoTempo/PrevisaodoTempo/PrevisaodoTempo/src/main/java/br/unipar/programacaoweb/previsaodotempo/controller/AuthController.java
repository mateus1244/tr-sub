package br.unipar.programacaoweb.previsaodotempo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @GetMapping("/login")
    public ResponseEntity<String> login() {
        // Em projetos simples o Spring Security já fornece o form padrão
        return ResponseEntity.ok("Página de login");
    }

    // Pode incluir endpoints para registro/add usuário
}