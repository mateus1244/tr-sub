package br.unipar.programacaoweb.previsaodotempo.service;

import br.unipar.programacaoweb.previsaodotempo.dto.WeatherResponseDTO;
import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import br.unipar.programacaoweb.previsaodotempo.repository.PrevisaoRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PrevisaoService {

    private final PrevisaoRepository repository;
    private final RestTemplate restTemplate;
    private final AlertaService alertaService;

    @Value("5bc4c7cbee8796e31e35a09e3e334b07")
    private String apiKey;  // Chave da API no application.properties

    // URL da API externa com placeholders para cidade e chave
    private final String WEATHER_API_URL_CITY_NAME = "https://api.openweathermap.org/data/2.5/weather?q={cidade}&appid={apiKey}&units=metric&lang=pt";
    private final String WEATHER_API_URL_CITY_ID = "https://api.openweathermap.org/data/2.5/weather?id={id}&appid={apiKey}&units=metric&lang=pt";

    public PrevisaoService(PrevisaoRepository repository, RestTemplate restTemplate, AlertaService alertaService) {
        this.repository = repository;
        this.restTemplate = restTemplate;
        this.alertaService = alertaService;
    }

    // CRUD
    public List<PrevisaoClimatica> listarTodas() {
        return repository.findAll();
    }

    public PrevisaoClimatica salvar(PrevisaoClimatica previsao) {
        return repository.save(previsao);
    }

    public PrevisaoClimatica buscarPorId(Long id) {
        return repository.findById(id).orElse(null);
    }

    public void excluir(Long id) {
        repository.deleteById(id);
    }

    // Chamada para API externa OpenWeatherMap para obter previsão pelo nome da cidade
    public PrevisaoClimatica obterPrevisaoPorCidade(String cidade) {
        WeatherResponseDTO response = restTemplate.getForObject(WEATHER_API_URL_CITY_NAME, WeatherResponseDTO.class, cidade, apiKey);
        return mapearESalvarPrevisao(response, cidade);
    }

    public PrevisaoClimatica obterPrevisaoPorId(Long id) {
        WeatherResponseDTO response = restTemplate.getForObject(WEATHER_API_URL_CITY_ID, WeatherResponseDTO.class, id, apiKey);
        // O nome da cidade virá na resposta da API, mas para o mapeamento inicial, passamos null
        return mapearESalvarPrevisao(response, null);
    }

    private PrevisaoClimatica mapearESalvarPrevisao(WeatherResponseDTO response, String cidadeParam) {
        if (response == null || response.getWeather().isEmpty()) return null;

        PrevisaoClimatica previsao = new PrevisaoClimatica();
        // Se a cidade não foi passada como parâmetro (caso de consulta por ID), pega da resposta da API
        previsao.setCidade(cidadeParam != null ? cidadeParam : response.getName());
        previsao.setDescricao(response.getWeather().get(0).getDescription());
        previsao.setTemperatura(response.getMain().getTemp());
        previsao.setUmidade(response.getMain().getHumidity());
        previsao.setDataHoraConsulta(LocalDateTime.now());

        salvar(previsao);
        
        // Verifica alertas após salvar a previsão
        List<String> alertasDisparados = alertaService.verificarAlertas(previsao);
        if (!alertasDisparados.isEmpty()) {
            System.out.println("\n========== ALERTAS DISPARADOS ==========");
            for (String alerta : alertasDisparados) {
                System.out.println("⚠️  " + alerta);
            }
            System.out.println("========================================\n");
        }
        
        return previsao;
    }

    // Atualiza a previsão para São Paulo a cada 5 minutos
    @Scheduled(fixedRate = 300000)
    public void atualizarPrevisaoSP() {
        obterPrevisaoPorCidade("São Paulo");
        System.out.println("Previsão para São Paulo atualizada automaticamente.");
    }

    @Scheduled(cron = "0 0 7 * * *")
    public void tarefaMatinal() {
        System.out.println("Executando tarefa matinal agendada...");
    }
}