package br.unipar.programacaoweb.previsaodotempo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Alerta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome do alerta não pode estar vazio")
    @Size(min = 3, max = 100, message = "Nome do alerta deve ter entre 3 e 100 caracteres")
    private String nome;

    @NotBlank(message = "Tipo de alerta não pode estar vazio")
    @Column(nullable = false)
    private String tipo; // "TEMPERATURA", "UMIDADE", "QUALIDADE_AR"

    @NotBlank(message = "Condição não pode estar vazia")
    @Column(nullable = false)
    private String condicao; // "MAIOR_QUE", "MENOR_QUE", "IGUAL_A"

    @NotNull(message = "Valor de referência não pode ser nulo")
    private Double valorReferencia;

    @NotBlank(message = "Cidade não pode estar vazia")
    @Size(min = 2, max = 100, message = "Cidade deve ter entre 2 e 100 caracteres")
    private String cidade;

    @Column(nullable = false)
    private Boolean ativo = true;

    @NotNull(message = "Data de criação não pode ser nula")
    private LocalDateTime dataCriacao;

    private LocalDateTime dataUltimoDisparo;

    @Column(length = 500)
    private String mensagemPersonalizada;
}
