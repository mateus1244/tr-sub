package br.unipar.programacaoweb.previsaodotempo.service;

import br.unipar.programacaoweb.previsaodotempo.dto.AlertaDTO;
import br.unipar.programacaoweb.previsaodotempo.model.Alerta;
import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import br.unipar.programacaoweb.previsaodotempo.repository.AlertaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class AlertaService {

    private final AlertaRepository alertaRepository;

    public AlertaService(AlertaRepository alertaRepository) {
        this.alertaRepository = alertaRepository;
    }

    /**
     * Cria um novo alerta personalizado
     */
    public Alerta criarAlerta(AlertaDTO alertaDTO) {
        Alerta alerta = Alerta.builder()
                .nome(alertaDTO.getNome())
                .tipo(alertaDTO.getTipo().toUpperCase())
                .condicao(alertaDTO.getCondicao().toUpperCase())
                .valorReferencia(alertaDTO.getValorReferencia())
                .cidade(alertaDTO.getCidade())
                .mensagemPersonalizada(alertaDTO.getMensagemPersonalizada())
                .ativo(true)
                .dataCriacao(LocalDateTime.now())
                .build();

        return alertaRepository.save(alerta);
    }

    /**
     * Lista todos os alertas
     */
    public List<Alerta> listarTodosAlertas() {
        return alertaRepository.findAll();
    }

    /**
     * Lista apenas alertas ativos
     */
    public List<Alerta> listarAlertasAtivos() {
        return alertaRepository.findByAtivoTrue();
    }

    /**
     * Busca alerta por ID
     */
    public Alerta buscarAlertaPorId(Long id) {
        return alertaRepository.findById(id).orElse(null);
    }

    /**
     * Ativa ou desativa um alerta
     */
    public Alerta alterarStatusAlerta(Long id, Boolean ativo) {
        Alerta alerta = buscarAlertaPorId(id);
        if (alerta != null) {
            alerta.setAtivo(ativo);
            return alertaRepository.save(alerta);
        }
        return null;
    }

    /**
     * Exclui um alerta
     */
    public void excluirAlerta(Long id) {
        alertaRepository.deleteById(id);
    }

    /**
     * Verifica se algum alerta foi disparado com base na previsão climática
     */
    public List<String> verificarAlertas(PrevisaoClimatica previsao) {
        List<Alerta> alertasAtivos = alertaRepository.findByCidadeAndAtivoTrue(previsao.getCidade());
        List<String> alertasDisparados = new ArrayList<>();

        for (Alerta alerta : alertasAtivos) {
            boolean disparar = false;
            double valorAtual = 0;

            // Determina o valor atual baseado no tipo de alerta
            switch (alerta.getTipo()) {
                case "TEMPERATURA":
                    valorAtual = previsao.getTemperatura();
                    break;
                case "UMIDADE":
                    valorAtual = previsao.getUmidade();
                    break;
                // Qualidade do ar pode ser adicionado futuramente quando a API fornecer esse dado
                default:
                    continue;
            }

            // Verifica a condição do alerta
            switch (alerta.getCondicao()) {
                case "MAIOR_QUE":
                    disparar = valorAtual > alerta.getValorReferencia();
                    break;
                case "MENOR_QUE":
                    disparar = valorAtual < alerta.getValorReferencia();
                    break;
                case "IGUAL_A":
                    disparar = Math.abs(valorAtual - alerta.getValorReferencia()) < 0.1;
                    break;
            }

            // Se o alerta foi disparado, registra
            if (disparar) {
                alerta.setDataUltimoDisparo(LocalDateTime.now());
                alertaRepository.save(alerta);

                String mensagem = alerta.getMensagemPersonalizada() != null 
                    ? alerta.getMensagemPersonalizada()
                    : String.format("ALERTA: %s - %s está %s %.1f (valor atual: %.1f) em %s",
                        alerta.getNome(),
                        alerta.getTipo(),
                        alerta.getCondicao().replace("_", " ").toLowerCase(),
                        alerta.getValorReferencia(),
                        valorAtual,
                        previsao.getCidade());

                alertasDisparados.add(mensagem);
            }
        }

        return alertasDisparados;
    }
}
