package br.unipar.programacaoweb.previsaodotempo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome de usuário não pode estar vazio")
    @Size(min = 3, max = 50, message = "Nome de usuário deve ter entre 3 e 50 caracteres")
    @Column(unique = true)
    private String username;

    @NotBlank(message = "Senha não pode estar vazia")
    @Size(min = 6, max = 255, message = "Senha deve ter pelo menos 6 caracteres")
    private String password;

    @NotBlank(message = "Papel (role) não pode estar vazio")
    private String role;

}
