package br.unipar.programacaoweb.previsaodotempo.dto;


import lombok.Data;

import java.util.List;

@Data
public class WeatherResponseDTO {

    private MainDTO main;

    private List<WeatherDTO> weather;

    private String name;

    @Data
    public static class MainDTO {
        private double temp;
        private int humidity;
    }

    @Data
    public static class WeatherDTO {
        private String description;
    }
}