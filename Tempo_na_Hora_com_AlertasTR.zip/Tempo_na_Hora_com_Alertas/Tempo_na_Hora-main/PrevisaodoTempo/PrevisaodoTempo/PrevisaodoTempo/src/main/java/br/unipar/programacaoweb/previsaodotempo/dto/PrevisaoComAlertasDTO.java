package br.unipar.programacaoweb.previsaodotempo.dto;

import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PrevisaoComAlertasDTO {
    
    private PrevisaoClimatica previsao;
    
    private List<String> alertasDisparados;
    
    private Boolean temAlertas;
}
