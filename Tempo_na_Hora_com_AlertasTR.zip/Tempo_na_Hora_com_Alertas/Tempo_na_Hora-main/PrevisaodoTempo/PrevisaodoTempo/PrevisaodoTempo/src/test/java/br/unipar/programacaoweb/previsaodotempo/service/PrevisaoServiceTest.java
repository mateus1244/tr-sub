package br.unipar.programacaoweb.previsaodotempo.service;

import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import br.unipar.programacaoweb.previsaodotempo.repository.PrevisaoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Testes do PrevisaoService")
class PrevisaoServiceTest {

    @Mock
    private PrevisaoRepository repository;

    @InjectMocks
    private PrevisaoService service;

    private PrevisaoClimatica previsao;

    @BeforeEach
    void setUp() {
        previsao = PrevisaoClimatica.builder()
                .id(1L)
                .cidade("São Paulo")
                .descricao("Céu limpo")
                .temperatura(25.5)
                .umidade(70.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();
    }

    @Test
    @DisplayName("Deve listar todas as previsões com sucesso")
    void testListarTodasComSucesso() {
        // Arrange
        PrevisaoClimatica previsao2 = PrevisaoClimatica.builder()
                .id(2L)
                .cidade("Rio de Janeiro")
                .descricao("Parcialmente nublado")
                .temperatura(28.0)
                .umidade(65.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        List<PrevisaoClimatica> previsoes = Arrays.asList(previsao, previsao2);
        when(repository.findAll()).thenReturn(previsoes);

        // Act
        List<PrevisaoClimatica> resultado = service.listarTodas();

        // Assert
        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals("São Paulo", resultado.get(0).getCidade());
        verify(repository, times(1)).findAll();
    }

    @Test
    @DisplayName("Deve buscar previsão por ID com sucesso")
    void testBuscarPorIdComSucesso() {
        // Arrange
        when(repository.findById(1L)).thenReturn(Optional.of(previsao));

        // Act
        PrevisaoClimatica resultado = service.buscarPorId(1L);

        // Assert
        assertNotNull(resultado);
        assertEquals("São Paulo", resultado.getCidade());
        assertEquals(25.5, resultado.getTemperatura());
        verify(repository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Deve retornar null ao buscar ID inexistente")
    void testBuscarPorIdNaoEncontrado() {
        // Arrange
        when(repository.findById(999L)).thenReturn(Optional.empty());

        // Act
        PrevisaoClimatica resultado = service.buscarPorId(999L);

        // Assert
        assertNull(resultado);
        verify(repository, times(1)).findById(999L);
    }

    @Test
    @DisplayName("Deve salvar previsão com sucesso")
    void testSalvarComSucesso() {
        // Arrange
        when(repository.save(any(PrevisaoClimatica.class))).thenReturn(previsao);

        // Act
        PrevisaoClimatica resultado = service.salvar(previsao);

        // Assert
        assertNotNull(resultado);
        assertEquals("São Paulo", resultado.getCidade());
        verify(repository, times(1)).save(any(PrevisaoClimatica.class));
    }

    @Test
    @DisplayName("Deve excluir previsão com sucesso")
    void testExcluirComSucesso() {
        // Act
        service.excluir(1L);

        // Assert
        verify(repository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("Deve validar temperatura dentro do intervalo permitido")
    void testValidarTemperaturaValida() {
        // Arrange
        PrevisaoClimatica previsaoValida = PrevisaoClimatica.builder()
                .id(1L)
                .cidade("São Paulo")
                .descricao("Céu limpo")
                .temperatura(25.5)
                .umidade(70.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        when(repository.save(any(PrevisaoClimatica.class))).thenReturn(previsaoValida);

        // Act
        PrevisaoClimatica resultado = service.salvar(previsaoValida);

        // Assert
        assertNotNull(resultado);
        assertTrue(resultado.getTemperatura() >= -50 && resultado.getTemperatura() <= 60);
    }

    @Test
    @DisplayName("Deve validar umidade dentro do intervalo permitido")
    void testValidarUmidadeValida() {
        // Arrange
        PrevisaoClimatica previsaoValida = PrevisaoClimatica.builder()
                .id(1L)
                .cidade("São Paulo")
                .descricao("Céu limpo")
                .temperatura(25.5)
                .umidade(70.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        when(repository.save(any(PrevisaoClimatica.class))).thenReturn(previsaoValida);

        // Act
        PrevisaoClimatica resultado = service.salvar(previsaoValida);

        // Assert
        assertNotNull(resultado);
        assertTrue(resultado.getUmidade() >= 0 && resultado.getUmidade() <= 100);
    }
}
