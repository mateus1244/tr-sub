package br.unipar.programacaoweb.previsaodotempo.controller;

import br.unipar.programacaoweb.previsaodotempo.model.PrevisaoClimatica;
import br.unipar.programacaoweb.previsaodotempo.repository.PrevisaoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("Testes de Integração do PrevisaoController")
class PrevisaoControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private PrevisaoRepository repository;

    @Autowired
    private ObjectMapper objectMapper;

    private PrevisaoClimatica previsao;

    @BeforeEach
    void setUp() {
        repository.deleteAll();

        previsao = PrevisaoClimatica.builder()
                .cidade("São Paulo")
                .descricao("Céu limpo e ensolarado")
                .temperatura(25.5)
                .umidade(70.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        previsao = repository.save(previsao);
    }

    @Test
    @DisplayName("Deve listar todas as previsões com sucesso")
    void testListarTodasPrevisoes() throws Exception {
        mockMvc.perform(get("/previsoes/Lista")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(greaterThanOrEqualTo(1))))
                .andExpect(jsonPath("$[0].cidade", equalTo("São Paulo")));
    }

    @Test
    @DisplayName("Deve buscar previsão por ID com sucesso")
    void testBuscarPrevisaoPorId() throws Exception {
        mockMvc.perform(get("/previsoes/1/{id}", previsao.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cidade", equalTo("São Paulo")))
                .andExpect(jsonPath("$.temperatura", equalTo(25.5)));
    }

    @Test
    @DisplayName("Deve retornar 404 ao buscar previsão inexistente")
    void testBuscarPrevisaoInexistente() throws Exception {
        mockMvc.perform(get("/previsoes/1/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Deve salvar nova previsão com sucesso")
    void testSalvarNovaPrevisao() throws Exception {
        PrevisaoClimatica novaPrevisao = PrevisaoClimatica.builder()
                .cidade("Rio de Janeiro")
                .descricao("Parcialmente nublado")
                .temperatura(28.0)
                .umidade(65.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        mockMvc.perform(post("/previsoes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(novaPrevisao)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cidade", equalTo("Rio de Janeiro")))
                .andExpect(jsonPath("$.temperatura", equalTo(28.0)));
    }

    @Test
    @DisplayName("Deve retornar erro ao salvar previsão com dados inválidos")
    void testSalvarPrevisaoComDadosInvalidos() throws Exception {
        PrevisaoClimatica previsaoInvalida = PrevisaoClimatica.builder()
                .cidade("") // Cidade vazia
                .descricao("Teste")
                .temperatura(25.5)
                .umidade(70.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        mockMvc.perform(post("/previsoes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(previsaoInvalida)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Deve atualizar previsão com sucesso")
    void testAtualizarPrevisao() throws Exception {
        PrevisaoClimatica previsaoAtualizada = PrevisaoClimatica.builder()
                .cidade("São Paulo")
                .descricao("Nublado com chuva")
                .temperatura(22.0)
                .umidade(85.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        mockMvc.perform(put("/previsoes/2/{id}", previsao.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(previsaoAtualizada)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.descricao", equalTo("Nublado com chuva")))
                .andExpect(jsonPath("$.temperatura", equalTo(22.0)));
    }

    @Test
    @DisplayName("Deve excluir previsão com sucesso")
    void testExcluirPrevisao() throws Exception {
        mockMvc.perform(delete("/previsoes/3/{id}", previsao.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        // Verificar se foi realmente deletado
        mockMvc.perform(get("/previsoes/1/{id}", previsao.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Deve retornar erro ao excluir previsão inexistente")
    void testExcluirPrevisaoInexistente() throws Exception {
        mockMvc.perform(delete("/previsoes/3/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Deve validar temperatura máxima permitida")
    void testValidarTemperaturaMaxima() throws Exception {
        PrevisaoClimatica previsaoComTemperaturaAlta = PrevisaoClimatica.builder()
                .cidade("São Paulo")
                .descricao("Muito quente")
                .temperatura(65.0) // Acima do máximo permitido (60)
                .umidade(70.0)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        mockMvc.perform(post("/previsoes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(previsaoComTemperaturaAlta)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Deve validar umidade máxima permitida")
    void testValidarUmidadeMaxima() throws Exception {
        PrevisaoClimatica previsaoComUmidadeAlta = PrevisaoClimatica.builder()
                .cidade("São Paulo")
                .descricao("Muito úmido")
                .temperatura(25.0)
                .umidade(105.0) // Acima do máximo permitido (100)
                .dataHoraConsulta(LocalDateTime.now())
                .build();

        mockMvc.perform(post("/previsoes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(previsaoComUmidadeAlta)))
                .andExpect(status().isBadRequest());
    }
}
