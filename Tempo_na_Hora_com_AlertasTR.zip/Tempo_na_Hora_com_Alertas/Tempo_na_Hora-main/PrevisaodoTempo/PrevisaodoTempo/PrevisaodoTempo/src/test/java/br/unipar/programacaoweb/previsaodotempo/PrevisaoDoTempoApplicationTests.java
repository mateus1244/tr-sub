package br.unipar.programacaoweb.previsaodotempo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrevisaoDoTempoApplicationTests {

    @Test
    void contextLoads() {
    }

}
